<?php 
	include '../koneksi.php';
	session_start();
	$id_user = $_SESSION['id_user'];
	$qry = mysql_query("UPDATE user SET status='logout' WHERE id_user='$id_user'");
	if ($qry) {
		session_unset();
		session_destroy();
		header("Location:index.php");
		
	}
?>