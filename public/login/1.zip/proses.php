<?php
	include "../koneksi.php";
	session_start();
	if (isset($_POST["Login"])) {
		$username = $_POST["username"];
		$password = $_POST["password"];
		$SetUser = mysql_real_escape_string($username);
		$SetPass = mysql_real_escape_string($password);
		$qry = mysql_query("SELECT * FROM user WHERE username ='$SetUser' OR password='$SetPass' ");
		$numRows = mysql_num_rows($qry);
		if ($numRows > 0) {
			$data = mysql_fetch_array($qry);
			$DbId_user =$data['id_user'];
			$DbUser = $data["username"];
			$DbPass = $data["password"];
			$DbLevel = $data["level"];
			$DbStatus = $data['status'];
			if ($DbStatus == "logout") {
				$UpdateStatus = mysql_query("UPDATE user SET status='login' WHERE id_user='$DbId_user' ");		
				if ($DbUser === $SetUser) {
					if ($DbPass === $SetPass) {
						
						$_SESSION["login"] = "login";
						$_SESSION["id_user"] = $data['id_user'];
						$_SESSION["nama"] = $data['nama'];
						if ($DbLevel == "admin") {
							header("Location:../superadmin/admin/index.php");
						}elseif ($DbLevel == "operator") {
							header("Location:../admin/index.php");
						}
					}
					else{
						header("Location:index.php?pesan=pass");
					}
				}
				else{
					header("Location:index.php?pesan=user");
				}
			}
			else{
			echo "<script>alert('Anda Sedang Login!!')</script>";
			$_SESSION["id_user"] = $data['id_user'];
			echo "<meta http-equiv='refresh' content='1 url=logout.php'>";
			}
			
		}
		else{
			header("Location:index.php?pesan=0");
		}
	}
?>